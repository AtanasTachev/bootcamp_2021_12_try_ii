const DB_NAME = 'recruitment';
const PORT = 5000;

module.exports = {
    DB_NAME,
    PORT,
};
