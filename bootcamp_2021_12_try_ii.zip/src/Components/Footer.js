import '../App.css';

const Footer = () => {
    return (<nav className="footer">
        <p>All rights reserved &copy;</p>
    </nav>);
}

export default Footer