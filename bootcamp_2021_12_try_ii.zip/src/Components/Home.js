import '../App.css';

const imageUrl = 'https://www.alacrityrs.com/wp-content/uploads/2021/10/Recruitment-Word-Cloud.jpeg'

const Home = () => {
    return (
        <>
            <img className='center' src={imageUrl} alt='backgroundImg' />
        </>
   );
}

export default Home